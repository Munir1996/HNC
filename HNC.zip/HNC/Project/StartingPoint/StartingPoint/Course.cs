﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace StartingPoint
{
    public class Course
    {
        public static string Name;
        public static string SCN;

        public static int ComputerSF;
        public static int DevelopingSI;
        public static int ProfessionalismEC;
        public static int TroubleshootingCP;
        public static int ProjectMI;

        public static int Average;
    }
}
