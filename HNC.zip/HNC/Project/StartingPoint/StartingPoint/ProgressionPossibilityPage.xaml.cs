﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace StartingPoint
{
    public partial class ProgressionPossibilityPage : PhoneApplicationPage
    {
        public ProgressionPossibilityPage()
        {
            InitializeComponent();
            
            //option starts as blank
            string option = "";
            //this will display the full name and scn
            txtName2.Text = "Your Name is " + Course.Name + "\n" + "Your SCN is " + Course.SCN;
            //this will show the average
            txtAverage.Text = "Your average mark is " + Course.Average;

            //if statement is used for taking the average and displaying the messages when needed
            if (Course.Average < 50)
            {
                option = ("No guaranteed progression to offer, student continues with remaining HNC units");
            }
            else if (Course.Average > 50 && Course.Average < 70)
            {
                option = ("Progression onto HND Networking or HND Software Development will be offered (conditional on the successful completion of all remaining HNC units");
            }
            else if (Course.Average > 70 && Course.Average < 80)
            {
                option = ("Progression onto the 2nd year of an appropriate degree Programme (conditional on the successful completion of all remaining HNC units");
            }
            else if (Course.Average > 80 && Course.Average < 100)
            {
                option = ("Progression onto the 2nd year of an appropriate degree Programme with possible company sponsorship (conditional on the successful completion of all remaining HNC units");
            }

            //display the option in this text black
            txtOption.Text = option;
        }

        private void btnFin_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }
    }
}