﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace StartingPoint
{
    public partial class HNCcomputing : PhoneApplicationPage
    {
        public HNCcomputing()
        {
            InitializeComponent();

            //display the name and course choice in the text block
            txtName1.Text = "Your name is " + Course.Name + "\n" + "Your SNC is " + Course.SCN;
            //set text box to max 3 characters 
            txtCSF.MaxLength = 3;
            txtDSI.MaxLength = 3;
            txtPEC.MaxLength = 3;
            txtPMI.MaxLength = 3;
            txtTCP.MaxLength = 3;
        }

        private void btnCheck_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                //this will store the marks and make sure all feilds are complete
                Course.ComputerSF = Convert.ToInt32(txtCSF.Text);
                Course.DevelopingSI = Convert.ToInt32(txtDSI.Text);
                Course.ProfessionalismEC = Convert.ToInt32(txtPEC.Text);
                Course.TroubleshootingCP = Convert.ToInt32(txtTCP.Text);
                Course.ProjectMI = Convert.ToInt32(txtPMI.Text);

                //if statement to make sure all textbox have only the values 0 to 100
                if (Course.ComputerSF < 0 || Course.ComputerSF > 100)
                {
                    MessageBox.Show("Computer Systems Fundamentals - Must be between 0 and 100");
                }
                else if (Course.DevelopingSI < 0 || Course.DevelopingSI > 100)
                {
                    MessageBox.Show("Developing Software: Introduction - Must be between 0 and 100");
                }
                else if (Course.ProjectMI < 0 || Course.ProjectMI > 100)
                {
                    MessageBox.Show("Project Management: An Introduction - Must be between 0 and 100");
                }
                else if (Course.TroubleshootingCP < 0 || Course.TroubleshootingCP > 100)
                {
                    MessageBox.Show("Troubleshooting Computing Problems - Must be between 0 and 100");
                }
                else if (Course.ProfessionalismEC < 0 || Course.ProfessionalismEC > 100)
                {
                    MessageBox.Show("Professionalism and Ethics in Computing - Must be between 0 and 100");
                }
                else
                {
                    MessageBox.Show("All Fields Valid");
                }

                // find the average
                Course.Average = (Course.ComputerSF + Course.DevelopingSI + Course.ProfessionalismEC + Course.TroubleshootingCP + Course.ProjectMI) / 5;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Must complete all fields");
            }            
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/ProgressionPossibilityPage.xaml", UriKind.Relative));
        }
    }
}