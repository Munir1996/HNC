﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace StartingPoint
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            //set text box to max 9 characters
            txtScn.MaxLength = 9;
        }

        private void btnContinue_Click(object sender, RoutedEventArgs e)
        {

            //this will store the name and the number to the class
                Course.Name = txtName.Text;
                Course.SCN = txtScn.Text;

            //SCN must be 9 characters at all time
            if (Course.SCN.Length < 9)
            {
                MessageBox.Show("SCN must be 9 characters");
            }
                //the name field must be filled
            else if (txtName.Text.Length <= 0)
            {
                MessageBox.Show("Must Enter Name");
            }
            else
            {
                //navigate to hnc computing
                NavigationService.Navigate(new Uri("/HNCcomputing.xaml", UriKind.Relative));
            }
            
        }

        private void btnHNCim_Click(object sender, RoutedEventArgs e)
        {
            //navigate hnc interactive media
            NavigationService.Navigate(new Uri("/HNCinteractiveMedia.xaml", UriKind.Relative));
        }

        private void btnHNCbm_Click(object sender, RoutedEventArgs e)
        {
            //naviagte to hnc business management
            NavigationService.Navigate(new Uri("/HNCbusinessManagement.xaml", UriKind.Relative));
        }
    }
}